from pathlib import Path
p=Path('/home/ubuntu/kisaan-kareer/client/src/auth.css')
s=p.read_text()
needle='.auth-brand-mark{width:36px;height:36px;border-radius:12px;display:grid;place-items:center;color:#d3e97a;background:#1d644c}'
replacement=needle+'.auth-brand-copy{display:flex;flex-direction:column;gap:2px}.auth-brand-copy strong{font-size:19px;line-height:1}.auth-brand-copy small{font-size:9px;line-height:1.2;font-weight:500;letter-spacing:.2px;color:#94b29a}'
if needle not in s: raise SystemExit('brand style marker not found')
p.write_text(s.replace(needle,replacement,1))
