import { afterEach, describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import * as db from "./db";

const ctx = {
  user: null,
  req: { protocol: "https", headers: {} },
  res: { clearCookie: vi.fn() },
} as unknown as TrpcContext;

describe("farmer data procedures", () => {
  afterEach(() => vi.restoreAllMocks());

  it("returns the demo farm context when a farmer is not signed in", async () => {
    const result = await appRouter.createCaller(ctx).farm.profile();
    expect(result.farmerName).toBe("Sneha Sharma");
    expect(result.district).toBe("Meerut");
    expect(result.farmSizeAcres).toBe("4.5");
  });

  it("returns the farmer's primary crop from the profile data model", async () => {
    const result = await appRouter.createCaller(ctx).farm.primaryCrop();
    expect(result.name).toBe("Wheat");
    expect(result.stage).toBe("Vegetative");
  });

  it("persists edited profile fields through the farm update procedure", async () => {
    const updatedFarm = { ...db.demoFarm, farmerName: "Asha Sharma", district: "Hapur", farmSizeAcres: "6" };
    vi.spyOn(db, "getFarmByOwner").mockResolvedValue(db.demoFarm);
    vi.spyOn(db, "upsertFarm").mockResolvedValue(updatedFarm);
    const result = await appRouter.createCaller(ctx).farm.update({
      farmerName: "Asha Sharma",
      district: "Hapur",
      farmSizeAcres: "6",
    });
    expect(db.upsertFarm).toHaveBeenCalledWith("demo-sneha", expect.objectContaining({ farmerName: "Asha Sharma", district: "Hapur", farmSizeAcres: "6" }));
    expect(result).toMatchObject({ farmerName: "Asha Sharma", district: "Hapur", farmSizeAcres: "6" });
  });

  it("returns actionable fallback alerts for the dashboard", async () => {
    const result = await appRouter.createCaller(ctx).alerts.list();
    expect(result.length).toBeGreaterThanOrEqual(3);
    expect(result[0]).toMatchObject({ kind: "weather", severity: "high" });
  });

  it("uses the market snapshot when a data.gov API key is not configured", async () => {
    const result = await appRouter.createCaller(ctx).market.list({ district: "Meerut" });
    expect(result.live).toBe(false);
    expect(result.items.some((item) => item.commodity === "Mustard")).toBe(true);
  });

  it("normalizes the live weather provider response", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        timezone: "Asia/Kolkata",
        current: { temperature_2m: 27.5, relative_humidity_2m: 70, precipitation: 0, weather_code: 1, wind_speed_10m: 9 },
        daily: { time: ["2026-09-12"], temperature_2m_max: [31], temperature_2m_min: [22], precipitation_probability_max: [20], weather_code: [1], wind_speed_10m_max: [12] },
      }),
    }));
    const result = await appRouter.createCaller(ctx).weather.current({ latitude: 28.9845, longitude: 77.7064 });
    expect(result.source).toContain("Open-Meteo");
    expect(result.current).toMatchObject({ temperature: 27.5, humidity: 70, rainProbability: 20, label: "Partly cloudy" });
    expect(result.daily[0]?.max).toBe(31);
  });
});
