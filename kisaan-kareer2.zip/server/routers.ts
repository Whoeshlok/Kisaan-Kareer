import { z } from "zod";
import { randomUUID } from "node:crypto";
import { COOKIE_NAME } from "@shared/const";
import { ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { sdk } from "./_core/sdk";
import { invokeLLM } from "./_core/llm";
import { storageGetSignedUrl, storagePut } from "./storage";
import {
  createLocalUser,
  createFarm,
  createCrop,
  getFarmsByOwner,
  getFarmById,
  getCrops,
  getTreatmentHistory,
  addTreatmentHistory,
  getIrrigationHistory,
  addIrrigationHistory,
  updateFarmById,
  demoFarm,
  getAlertsForOwner,
  getFarmByOwner,
  getUserByEmail,
  getLatestSoilTest,
  getLatestWeatherSnapshot,
  getMarketPrices,
  getPrimaryCrop,
  getRecentChat,
  getRecentDiseaseScans,
  getRecommendation,
  markAlertRead,
  saveChat,
  saveDiseaseScan,
  saveWeatherSnapshot,
  upsertFarm,
  upsertPrimaryCrop,
  upsertMarketPrice,
} from "./db";
import { hashPassword, verifyPassword } from "./password";

const DEMO_MARKETS = [
  { commodity: "Wheat", market: "Meerut Mandi", modalPrice: "2350", minPrice: "2260", maxPrice: "2420", change: 2, priceDate: "2026-09-12", source: "Agmarknet demo snapshot" },
  { commodity: "Rice", market: "Meerut Mandi", modalPrice: "3120", minPrice: "2980", maxPrice: "3260", change: 1, priceDate: "2026-09-12", source: "Agmarknet demo snapshot" },
  { commodity: "Mustard", market: "Meerut Mandi", modalPrice: "5460", minPrice: "5300", maxPrice: "5600", change: 3, priceDate: "2026-09-12", source: "Agmarknet demo snapshot" },
  { commodity: "Sugarcane", market: "Meerut Mandi", modalPrice: "340", minPrice: "330", maxPrice: "350", change: 0, priceDate: "2026-09-12", source: "Agmarknet demo snapshot" },
  { commodity: "Potato", market: "Meerut Mandi", modalPrice: "1180", minPrice: "1080", maxPrice: "1260", change: 2.6, priceDate: "2026-09-12", source: "Agmarknet demo snapshot" },
];

const weatherLabel = (code: number) => {
  if (code === 0) return "Clear sky";
  if ([1, 2].includes(code)) return "Partly cloudy";
  if (code === 3) return "Overcast";
  if ([45, 48].includes(code)) return "Foggy";
  if ([51, 53, 55, 56, 57].includes(code)) return "Light drizzle";
  if ([61, 63, 65, 80, 81, 82].includes(code)) return "Rain showers";
  if ([95, 96, 99].includes(code)) return "Thunderstorms";
  return "Mixed conditions";
};

const ownerId = (ctx: { user?: { openId: string } | null }) => ctx.user?.openId ?? "demo-sneha";

async function fetchWeather(latitude: number, longitude: number, ownerOpenId: string) {
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude", String(latitude));
  url.searchParams.set("longitude", String(longitude));
  url.searchParams.set("current", "temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m");
  url.searchParams.set("daily", "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max");
  url.searchParams.set("forecast_days", "5");
  url.searchParams.set("timezone", "auto");
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Weather provider returned ${response.status}`);
  const data = await response.json() as any;
  const currentCode = Number(data.current?.weather_code ?? 2);
  const result = {
    source: "Open-Meteo live forecast",
    timezone: data.timezone,
    current: {
      temperature: Number(data.current?.temperature_2m ?? 28),
      humidity: Number(data.current?.relative_humidity_2m ?? 72),
      rainfall: Number(data.current?.precipitation ?? 0),
      rainProbability: Number(data.daily?.precipitation_probability_max?.[0] ?? 20),
      windSpeed: Number(data.current?.wind_speed_10m ?? 12),
      code: currentCode,
      label: weatherLabel(currentCode),
    },
    daily: (data.daily?.time ?? []).map((date: string, index: number) => ({
      date,
      max: Number(data.daily.temperature_2m_max?.[index] ?? 28),
      min: Number(data.daily.temperature_2m_min?.[index] ?? 20),
      probability: Number(data.daily.precipitation_probability_max?.[index] ?? 20),
      code: Number(data.daily.weather_code?.[index] ?? 2),
      label: weatherLabel(Number(data.daily.weather_code?.[index] ?? 2)),
      wind: Number(data.daily.wind_speed_10m_max?.[index] ?? 12),
    })),
  };
  await saveWeatherSnapshot({ ownerOpenId, latitude, longitude, timezone: result.timezone, payload: result, source: "Open-Meteo live forecast" });
  return result;
}

async function fetchMarkets(district: string, ownerOpenId: string) {
  const apiKey = process.env.DATA_GOV_API_KEY;
  if (!apiKey) {
    const stored = await getMarketPrices(district);
    if (stored.length) return { source: "Project database · seeded market snapshot", live: false, items: stored.map((row) => ({ ...row, change: Number(row.changePercent) })) };
    return { source: "Demo snapshot · add DATA_GOV_API_KEY for live Agmarknet data", live: false, items: DEMO_MARKETS };
  }
  const url = new URL("https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070");
  url.searchParams.set("api-key", apiKey);
  url.searchParams.set("format", "json");
  url.searchParams.set("limit", "100");
  url.searchParams.set("filters[State]", "Uttar Pradesh");
  url.searchParams.set("filters[District]", district);
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Mandi provider returned ${response.status}`);
    const data = await response.json() as any;
    const items = (data.records ?? []).slice(0, 20).map((record: any) => ({
      commodity: record.Commodity ?? record.commodity ?? "Unknown crop",
      market: record.Market ?? record.market ?? `${district} Mandi`,
      modalPrice: String(record.Modal_Price ?? record.modal_price ?? record.ModalPrice ?? "0"),
      minPrice: String(record.Min_Price ?? record.min_price ?? "0"),
      maxPrice: String(record.Max_Price ?? record.max_price ?? "0"),
      change: 0,
      priceDate: record.Arrival_Date ?? record.arrival_date ?? new Date().toISOString().slice(0, 10),
      source: "data.gov.in · Agmarknet",
    }));
    for (const item of items) await upsertMarketPrice({ district, market: item.market, commodity: item.commodity, modalPrice: item.modalPrice, minPrice: item.minPrice, maxPrice: item.maxPrice, changePercent: String(item.change), priceDate: item.priceDate, source: item.source });
    return { source: "data.gov.in · Agmarknet live feed · cached in project database", live: true, items: items.length ? items : DEMO_MARKETS };
  } catch (error) {
    console.error("[Market] provider failed", error);
    const stored = await getMarketPrices(district);
    return { source: "Project database · last available market snapshot", live: false, items: stored.length ? stored.map((row) => ({ ...row, change: Number(row.changePercent) })) : DEMO_MARKETS };
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    signup: publicProcedure.input(z.object({ name: z.string().min(2).max(120), email: z.string().email(), password: z.string().min(8).max(120) })).mutation(async ({ ctx, input }) => {
      const email = input.email.trim().toLowerCase();
      if (await getUserByEmail(email)) throw new TRPCError({ code: "CONFLICT", message: "An account with this email already exists." });
      const openId = `local-${randomUUID()}`;
      const user = await createLocalUser({ openId, name: input.name.trim(), email, passwordHash: await hashPassword(input.password) });
      if (!user) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Could not create your account." });
      await upsertFarm(openId, { farmerName: input.name.trim(), language: "English", location: "India", district: "Not set", state: "Not set", latitude: "20.5937", longitude: "78.9629", farmSizeAcres: "1", irrigationMethod: "Not set", farmingPreference: "Conventional" });
      const token = await sdk.signSession({ openId, appId: process.env.VITE_APP_ID ?? "", name: input.name.trim() });
      ctx.res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(ctx.req), maxAge: ONE_YEAR_MS });
      return { user };
    }),
    signin: publicProcedure.input(z.object({ email: z.string().email(), password: z.string().min(1) })).mutation(async ({ ctx, input }) => {
      const user = await getUserByEmail(input.email.trim().toLowerCase());
      if (!user?.passwordHash || !(await verifyPassword(input.password, user.passwordHash))) throw new TRPCError({ code: "UNAUTHORIZED", message: "Email or password is incorrect." });
      const token = await sdk.signSession({ openId: user.openId, appId: process.env.VITE_APP_ID ?? "", name: user.name ?? "Farmer" });
      ctx.res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(ctx.req), maxAge: ONE_YEAR_MS });
      return { user };
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  farm: router({
    list: publicProcedure.query(({ ctx }) => getFarmsByOwner(ownerId(ctx))),
    profile: publicProcedure.input(z.object({ farmId: z.number().optional() }).optional()).query(({ ctx, input }) => input?.farmId ? getFarmById(ownerId(ctx), input.farmId) : getFarmByOwner(ownerId(ctx))),
    crops: publicProcedure.input(z.object({ farmId: z.number().optional() }).optional()).query(async ({ ctx, input }) => { const farm = input?.farmId ? await getFarmById(ownerId(ctx), input.farmId) : await getFarmByOwner(ownerId(ctx)); return getCrops(farm.id); }),
    primaryCrop: publicProcedure.input(z.object({ farmId: z.number().optional() }).optional()).query(async ({ ctx, input }) => { const farm = input?.farmId ? await getFarmById(ownerId(ctx), input.farmId) : await getFarmByOwner(ownerId(ctx)); return getPrimaryCrop(farm.id); }),
    soil: publicProcedure.input(z.object({ farmId: z.number().optional() }).optional()).query(async ({ ctx, input }) => { const farm = input?.farmId ? await getFarmById(ownerId(ctx), input.farmId) : await getFarmByOwner(ownerId(ctx)); return getLatestSoilTest(farm.id); }),
    create: publicProcedure.input(z.object({ farmerName: z.string().min(2), location: z.string().min(2), district: z.string().min(2), state: z.string().min(2), latitude: z.string(), longitude: z.string(), farmSizeAcres: z.string(), language: z.string().default("English"), irrigationMethod: z.string().default("Tube well"), farmingPreference: z.string().default("Conventional"), soilType: z.string().default("Not tested"), soilReportAvailable: z.number().default(0), irrigationFrequency: z.string().default("As needed") })).mutation(({ ctx, input }) => createFarm(ownerId(ctx), input)),
    addCrop: publicProcedure.input(z.object({ farmId: z.number(), name: z.string().min(1), variety: z.string().optional(), stage: z.string().optional(), sowingDate: z.string().optional(), harvestDate: z.string().optional(), chemicalName: z.string().optional() })).mutation(({ input }) => createCrop(input.farmId, input)),
    treatments: publicProcedure.input(z.object({ farmId: z.number().optional() }).optional()).query(async ({ ctx, input }) => { const farm = input?.farmId ? await getFarmById(ownerId(ctx), input.farmId) : await getFarmByOwner(ownerId(ctx)); return getTreatmentHistory(farm.id); }),
    addTreatment: publicProcedure.input(z.object({ farmId: z.number(), cropId: z.number().optional(), treatmentDate: z.string(), chemicalName: z.string().min(1), quantity: z.string().optional(), notes: z.string().optional() })).mutation(({ input }) => addTreatmentHistory(input)),
    irrigations: publicProcedure.input(z.object({ farmId: z.number().optional() }).optional()).query(async ({ ctx, input }) => { const farm = input?.farmId ? await getFarmById(ownerId(ctx), input.farmId) : await getFarmByOwner(ownerId(ctx)); return getIrrigationHistory(farm.id); }),
    addIrrigation: publicProcedure.input(z.object({ farmId: z.number(), cropId: z.number().optional(), irrigationDate: z.string(), method: z.string().optional(), duration: z.string().optional(), notes: z.string().optional() })).mutation(({ input }) => addIrrigationHistory(input)),
    update: publicProcedure.input(z.object({ farmId: z.number().optional(),
      farmerName: z.string().min(2).optional(), location: z.string().min(2).optional(), district: z.string().min(2).optional(),
      state: z.string().min(2).optional(), latitude: z.string().optional(), longitude: z.string().optional(), farmSizeAcres: z.string().optional(),
      language: z.string().optional(), irrigationMethod: z.string().optional(), farmingPreference: z.string().optional(), soilType: z.string().optional(), soilReportAvailable: z.number().int().min(0).max(1).optional(), irrigationFrequency: z.string().optional(),
      cropName: z.string().optional(), cropVariety: z.string().optional(), sowingDate: z.string().optional(), harvestDate: z.string().optional(), treatmentDate: z.string().optional(), treatmentQuantity: z.string().optional(), chemicalName: z.string().optional(),
    })).mutation(async ({ ctx, input }) => {
      const current = input.farmId ? await getFarmById(ownerId(ctx), input.farmId) : await getFarmByOwner(ownerId(ctx));
      const farmValues = {
        farmerName: input.farmerName ?? current.farmerName,
        location: input.location ?? current.location,
        district: input.district ?? current.district,
        state: input.state ?? current.state,
        latitude: input.latitude ?? current.latitude,
        longitude: input.longitude ?? current.longitude,
        farmSizeAcres: input.farmSizeAcres ?? current.farmSizeAcres,
        language: input.language ?? current.language,
        irrigationMethod: input.irrigationMethod ?? current.irrigationMethod,
        farmingPreference: input.farmingPreference ?? current.farmingPreference,
        soilType: input.soilType ?? (current as any).soilType ?? "Not tested",
        soilReportAvailable: input.soilReportAvailable ?? (current as any).soilReportAvailable ?? 0,
        irrigationFrequency: input.irrigationFrequency ?? (current as any).irrigationFrequency ?? "As needed",
      };
      await (input.farmId ? updateFarmById(ownerId(ctx), input.farmId, farmValues) : upsertFarm(ownerId(ctx), farmValues));
      if (input.cropName || input.cropVariety || input.sowingDate || input.harvestDate || input.treatmentDate || input.treatmentQuantity || input.chemicalName) {
        const crop = await getPrimaryCrop(current.id);
        await upsertPrimaryCrop(current.id, { name: input.cropName ?? crop?.name ?? "Wheat", variety: input.cropVariety ?? crop?.variety ?? "", stage: crop?.stage ?? "Planning", sowingDate: input.sowingDate ?? crop?.sowingDate ?? "", harvestDate: input.harvestDate ?? (crop as any)?.harvestDate ?? "", treatmentDate: input.treatmentDate ?? (crop as any)?.treatmentDate ?? "", treatmentQuantity: input.treatmentQuantity ?? (crop as any)?.treatmentQuantity ?? "", chemicalName: input.chemicalName ?? (crop as any)?.chemicalName ?? "" });
      }
      return input.farmId ? getFarmById(ownerId(ctx), input.farmId) : getFarmByOwner(ownerId(ctx));
    }),
  }),
  soil: router({
    suggest: publicProcedure.input(z.object({ latitude: z.number(), longitude: z.number() })).query(async ({ input }) => {
      try {
        const url = new URL("https://rest.isric.org/soilgrids/v2.0/properties/query");
        url.searchParams.set("lon", String(input.longitude)); url.searchParams.set("lat", String(input.latitude));
        url.searchParams.set("property", "clay"); url.searchParams.set("property", "sand"); url.searchParams.set("property", "silt"); url.searchParams.set("depth", "0-5cm"); url.searchParams.set("value", "mean");
        const response = await fetch(url); if (!response.ok) throw new Error("SoilGrids unavailable");
        const data = await response.json() as any; const values = data.properties?.layers?.map((layer: any) => Number(layer.depths?.[0]?.values?.mean ?? 0)) ?? [];
        const [clay, sand, silt] = values; const type = clay > sand && clay > silt ? "Clay soil" : sand > silt ? "Sandy soil" : "Loam soil";
        return { source: "ISRIC SoilGrids", type, clay, sand, silt };
      } catch { return { source: "Location estimate", type: "Loam soil", clay: null, sand: null, silt: null }; }
    }),
  }),
  weather: router({
    current: publicProcedure.input(z.object({ latitude: z.number(), longitude: z.number() })).query(async ({ ctx, input }) => {
      try { return await fetchWeather(input.latitude, input.longitude, ownerId(ctx)); }
      catch (error) {
        console.error("[Weather] provider failed", error);
        const cached = await getLatestWeatherSnapshot(ownerId(ctx), input.latitude, input.longitude);
        if (cached) return cached;
        throw error;
      }
    }),
  }),
  location: router({
    reverse: publicProcedure.input(z.object({ latitude: z.number(), longitude: z.number() })).mutation(async ({ input }) => {
      const url = new URL("https://nominatim.openstreetmap.org/reverse");
      url.searchParams.set("format", "jsonv2");
      url.searchParams.set("lat", String(input.latitude));
      url.searchParams.set("lon", String(input.longitude));
      url.searchParams.set("zoom", "18");
      url.searchParams.set("addressdetails", "1");
      const response = await fetch(url, { headers: { "User-Agent": "Kisaan-Kareer/1.0 farmer-dashboard" } });
      if (!response.ok) throw new Error(`Location provider returned ${response.status}`);
      const data = await response.json() as { display_name?: string; address?: Record<string, string> };
      const address = data.address ?? {};
      const village = address.village ?? address.hamlet ?? address.town ?? address.city ?? address.municipality ?? "Your area";
      const district = address.state_district ?? address.district ?? address.county ?? village;
      const state = address.state ?? "India";
      const country = address.country ?? "India";
      return { label: [village, district, state].filter((value, index, values) => value && values.indexOf(value) === index).join(", "), village, district, state, country, displayName: data.display_name ?? village };
    }),
  }),
  market: router({
    list: publicProcedure.input(z.object({ district: z.string().default("Meerut") })).query(({ ctx, input }) => fetchMarkets(input.district, ownerId(ctx))),
  }),
  alerts: router({
    list: publicProcedure.query(async ({ ctx }) => {
      const rows = await getAlertsForOwner(ownerId(ctx));
      if (rows.length) return rows;
      return [
        { id: 1, kind: "weather", severity: "high", title: "High chance of rain in next 2 days", message: "Plan harvesting accordingly.", createdAt: new Date(Date.now() - 2 * 3600_000), readAt: null },
        { id: 2, kind: "market", severity: "medium", title: "Price of mustard increased by 3%", message: "Good time to sell in Meerut mandi.", createdAt: new Date(Date.now() - 4 * 3600_000), readAt: null },
        { id: 3, kind: "crop", severity: "high", title: "Possible fungal infection in wheat", message: "Check for yellowing leaves.", createdAt: new Date(Date.now() - 6 * 3600_000), readAt: null },
      ];
    }),
    markRead: publicProcedure.input(z.object({ id: z.number() })).mutation(({ ctx, input }) => markAlertRead(ownerId(ctx), input.id)),
  }),
  decision: router({
    current: publicProcedure.query(({ ctx }) => getRecommendation(ownerId(ctx))),
  }),
  chat: router({
    history: publicProcedure.query(({ ctx }) => getRecentChat(ownerId(ctx))),
  }),
  disease: router({
    recent: publicProcedure.query(({ ctx }) => getRecentDiseaseScans(ownerId(ctx))),
    analyze: publicProcedure.input(z.object({ dataUrl: z.string().min(20), mimeType: z.string().default("image/jpeg") })).mutation(async ({ ctx, input }) => {
      const match = input.dataUrl.match(/^data:([^;]+);base64,(.+)$/);
      if (!match) throw new Error("Please upload a valid image");
      const buffer = Buffer.from(match[2], "base64");
      const stored = await storagePut(`crop-images/${Date.now()}.jpg`, buffer, input.mimeType);
      try {
        const signedUrl = await storageGetSignedUrl(stored.key);
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "You are a crop disease scout. Identify the most likely issue from the image, give confidence, severity, and three safe next steps. Do not claim certainty; advise a local agronomist for confirmation." },
            { role: "user", content: [{ type: "text", text: "Analyze this crop or leaf image." }, { type: "image_url", image_url: { url: signedUrl, detail: "high" } }] },
          ],
          maxTokens: 450,
        });
        const raw = response.choices?.[0]?.message?.content;
        const diagnosis = typeof raw === "string" ? raw : "Possible fungal leaf spot. Isolate affected leaves and consult an agronomist.";
        await saveDiseaseScan({ ownerOpenId: ownerId(ctx), imageUrl: stored.url, diagnosis, source: "AI image analysis" });
        return { imageUrl: stored.url, diagnosis, source: "AI image analysis" };
      } catch (error) {
        console.error("[Disease] analysis failed", error);
        const diagnosis = "Image saved. The AI scout is unavailable right now; check for yellowing, lesions or curling and consult a local agronomist.";
        await saveDiseaseScan({ ownerOpenId: ownerId(ctx), imageUrl: stored.url, diagnosis, source: "Image saved · manual review needed" });
        return { imageUrl: stored.url, diagnosis, source: "Image saved · manual review needed" };
      }
    }),
  }),
  assistant: router({
    ask: publicProcedure.input(z.object({ question: z.string().min(1), history: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() })).default([]) })).mutation(async ({ ctx, input }) => {
      const farm = await getFarmByOwner(ownerId(ctx));
      const crop = await getPrimaryCrop(farm.id);
      await saveChat(ownerId(ctx), "user", input.question);
      try {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: `You are Kisaan-Kareer, a practical farming decision companion. Answer in concise, plain English. Give one clear action, timing, and reason. Farm: ${farm.location}, ${farm.farmSizeAcres} acres, ${farm.farmingPreference}. Crop: ${crop.name}, stage ${crop.stage}.` },
            ...input.history.map(item => ({ role: item.role, content: item.content })),
            { role: "user", content: input.question },
          ],
          maxTokens: 350,
        });
        const raw = response.choices?.[0]?.message?.content;
        const answer = typeof raw === "string" ? raw : "Check soil moisture before irrigation and avoid watering during midday.";
        await saveChat(ownerId(ctx), "assistant", answer);
        return { answer, source: "Kisaan-Kareer AI decision engine" };
      } catch (error) {
        console.error("[Assistant] LLM request failed", error);
        const answer = "Based on your wheat crop and current farm conditions, check soil moisture first and water in the early morning. I’ll keep this recommendation practical until the AI service reconnects.";
        await saveChat(ownerId(ctx), "assistant", answer);
        return { answer, source: "Farm rules fallback" };
      }
    }),
  }),
});

export type AppRouter = typeof appRouter;
