import { seedDemoData } from "./db";

async function main() {
  const result = await seedDemoData();
  console.log(`[Seed] Demo farmer data ready: ${JSON.stringify(result)}`);
  process.exit(0);
}

main().catch((error) => {
  console.error("[Seed] Failed:", error);
  process.exitCode = 1;
});
