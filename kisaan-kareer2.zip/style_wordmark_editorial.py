from pathlib import Path
css=Path('/home/ubuntu/kisaan-kareer/client/src/index.css')
s=css.read_text()
s=s.replace("family=DM+Sans:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,600", "family=Cormorant+Garamond:ital,wght@0,600;0,700;1,600;1,700&family=DM+Sans:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,600")
css.write_text(s)
auth=Path('/home/ubuntu/kisaan-kareer/client/src/auth.css')
s=auth.read_text()
old='.auth-brand-copy{display:flex;flex-direction:column;gap:3px}.auth-brand-copy strong{font-family:Fraunces,serif;font-size:22px;line-height:.95;letter-spacing:-.7px;color:#d4e98b;font-weight:650}.auth-brand-copy small{font-size:9px;line-height:1.2;font-weight:500;letter-spacing:.35px;color:#aac2a5;text-transform:uppercase}'
new='.auth-brand-copy{display:flex;flex-direction:column;gap:1px}.auth-brand-copy strong{font-family:"Cormorant Garamond",serif;font-size:29px;line-height:.78;letter-spacing:-1.1px;color:#e1f09a;font-weight:700;font-style:italic}.auth-brand-copy small{font-size:8px;line-height:1.25;font-weight:700;letter-spacing:1.4px;color:#adc8a4;text-transform:uppercase}'
if old not in s: raise SystemExit('current wordmark rule not found')
auth.write_text(s.replace(old,new,1))
