import { useEffect, useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import {
  Bell, BrainCircuit, ChevronDown, ChevronRight, CloudSun, Droplets,
  Home as HomeIcon, Leaf, Menu, Mic, Paperclip, Search, Send, Settings,
  ShoppingBasket, Sprout, TrendingUp, Upload, Wind, MapPin, ShieldCheck,
  Sparkles, Sun, ThermometerSun, CircleHelp, Languages,
} from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";

const heroImage = "/manus-storage/kisaan-field_e6490dd2.jpg";
const fallbackCoordinates = { latitude: 28.9845, longitude: 77.7064 };
const fallbackMarketRows = [
  { commodity: "Wheat", market: "Meerut Mandi", modalPrice: "2350", change: 2 },
  { commodity: "Rice", market: "Meerut Mandi", modalPrice: "3120", change: 1 },
  { commodity: "Mustard", market: "Meerut Mandi", modalPrice: "5460", change: 3 },
  { commodity: "Sugarcane", market: "Meerut Mandi", modalPrice: "340", change: 0 },
];
const cropEmoji: Record<string, string> = { Wheat: "🌾", Rice: "🌾", Mustard: "🌿", Sugarcane: "🌽", Potato: "🥔" };

const navItems = [
  { label: "Home", icon: HomeIcon }, { label: "Weather", icon: CloudSun },
  { label: "Mandi Prices", icon: ShoppingBasket }, { label: "Disease Detection", icon: Leaf },
  { label: "Decision Engine", icon: BrainCircuit }, { label: "Chat with AI", icon: CircleHelp },
  { label: "Alerts", icon: Bell }, { label: "Farm Profile", icon: Sprout },
];

const quickActions = [
  { title: "Check Weather", sub: "Plan your farming activities", target: "Weather", icon: CloudSun, tone: "blue" },
  { title: "Mandi Prices", sub: "Get latest crop prices", target: "Mandi Prices", icon: ShoppingBasket, tone: "green" },
  { title: "Detect Disease", sub: "Upload image & get solution", target: "Disease Detection", icon: Leaf, tone: "lime" },
  { title: "Get Suggestions", sub: "AI based farming advice", target: "Decision Engine", icon: BrainCircuit, tone: "violet" },
  { title: "Chat with AI", sub: "Ask anything about farming", target: "Chat with AI", icon: CircleHelp, tone: "teal" },
];

function SectionHeader({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return <div className="section-header"><h2>{title}</h2>{action && <button onClick={onAction ?? (() => toast.success(`${action.replace("→", "").trim()} updated`))}>{action} <ChevronRight size={15} /></button>}</div>;
}

function Workspace({ active, onNavigate, weather, market, farm, crop, soil, recommendation, alerts, recentScans, onLogout, farmProfileForm, updateFarmProfileField, saveFarmProfile, profileUpdateMutation, farms, crops, treatments, irrigations, soilSuggestion, onAddFarm, onAddCrop, onAddTreatment, onAddIrrigation }: { active: string; onNavigate: (label: string) => void; weather?: any; market?: any; farm?: any; crop?: any; soil?: any; recommendation?: any; alerts?: any[]; recentScans?: any[]; onLogout: () => Promise<void>; farmProfileForm: any; updateFarmProfileField: (field: string, value: string | number) => void; saveFarmProfile: () => void; profileUpdateMutation: any; farms: any[]; crops: any[]; treatments: any[]; irrigations: any[]; soilSuggestion?: any; onAddFarm: (input: any) => void; onAddCrop: (input: any) => void; onAddTreatment: (input: any) => void; onAddIrrigation: (input: any) => void }) {
  const diseaseMutation = trpc.disease.analyze.useMutation();
  const profileMutation = trpc.farm.update.useMutation();
  const trpcUtils = trpc.useUtils();
  const [editingProfile, setEditingProfile] = useState(false);
  const [profileForm, setProfileForm] = useState({
    farmerName: farm?.farmerName ?? "Sneha Sharma",
    location: farm?.location ?? "Meerut, Uttar Pradesh",
    district: farm?.district ?? "Meerut",
    state: farm?.state ?? "Uttar Pradesh",
    farmSizeAcres: farm?.farmSizeAcres ?? "4.5",
    language: farm?.language ?? "English · Hindi",
    irrigationMethod: farm?.irrigationMethod ?? "Tube well",
    farmingPreference: farm?.farmingPreference ?? "Conventional",
  });
  useEffect(() => {
    if (!farm) return;
    setProfileForm({
      farmerName: farm.farmerName,
      location: farm.location,
      district: farm.district,
      state: farm.state,
      farmSizeAcres: farm.farmSizeAcres,
      language: farm.language,
      irrigationMethod: farm.irrigationMethod,
      farmingPreference: farm.farmingPreference,
    });
  }, [farm]);
  const updateProfileField = (field: keyof typeof profileForm, value: string) => setProfileForm((current) => ({ ...current, [field]: value }));
  const saveProfile = async () => {
    try {
      await profileMutation.mutateAsync(profileForm);
      await Promise.all([
        trpcUtils.farm.profile.invalidate(),
        trpcUtils.farm.primaryCrop.invalidate(),
        trpcUtils.weather.current.invalidate(),
        trpcUtils.market.list.invalidate(),
      ]);
      setEditingProfile(false);
      toast.success("Farm profile saved to your database");
    } catch {
      toast.error("Could not save the farm profile. Please try again.");
    }
  };
  const handleDiseaseUpload = (file?: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => diseaseMutation.mutate({ dataUrl: String(reader.result), mimeType: file.type }, {
      onSuccess: (result) => { trpcUtils.disease.recent.invalidate(); toast.success(`${result.source}: ${result.diagnosis.slice(0, 90)}…`); },
      onError: () => toast.error("Image analysis could not be completed. Please try again."),
    });
    reader.readAsDataURL(file);
  };
  const configs: Record<string, { eyebrow: string; title: string; description: string; icon: typeof CloudSun; tone: string }> = {
    Weather: { eyebrow: "LIVE FARM CONDITIONS", title: "Weather that turns into action", description: "Plan irrigation, spraying and harvesting around the next 5 days.", icon: CloudSun, tone: "blue" },
    "Mandi Prices": { eyebrow: "MARKET INTELLIGENCE", title: "Sell with better timing", description: "Compare today's mandi rates and follow the crops moving up.", icon: ShoppingBasket, tone: "green" },
    "Disease Detection": { eyebrow: "CROP HEALTH PILOT", title: "Spot crop issues early", description: "Upload a leaf photo and get an AI-guided next step for wheat, rice or mustard.", icon: Leaf, tone: "lime" },
    "Decision Engine": { eyebrow: "PERSONALIZED RECOMMENDATION", title: "Your farm, one clear decision", description: "Kisaan-Kareer combines crop stage, soil, weather and market context.", icon: BrainCircuit, tone: "violet" },
    Alerts: { eyebrow: "PROACTIVE FARM SIGNALS", title: "Stay ahead of important changes", description: "Weather, crop-health and price alerts in one calm, actionable feed.", icon: Bell, tone: "teal" },
    Settings: { eyebrow: "ACCOUNT SETTINGS", title: "Keep your workspace personal", description: "Manage language, profile preferences, location and access.", icon: Settings, tone: "green" },
    "Farm Profile": { eyebrow: "FARM PROFILE", title: "Your complete farm context", description: "Keep farm, soil and crop details ready for better recommendations.", icon: Sprout, tone: "green" },
  };
  const config = configs[active];
  if (!config) return null;
  const Icon = config.icon;
  const farmLocation = farm?.location ?? "Meerut, Uttar Pradesh";
  const cropName = crop?.name ?? "Wheat";
  const cropStage = crop?.stage ?? "Vegetative";
  const savedRecommendation = recommendation ?? { title: "Check soil moisture before irrigation", body: "Your saved recommendation will appear here after the farm profile is loaded.", confidence: "DATABASE READY", factors: JSON.stringify(["Farm profile", "Crop stage", "Weather"]) };
  const factorList = (() => { try { return JSON.parse(savedRecommendation.factors); } catch { return ["Farm profile", "Crop stage", "Weather"]; } })();

  return <div className="workspace-view">
    <div className="workspace-hero"><div><div className="eyebrow">{config.eyebrow}</div><h1>{config.title}</h1><p>{config.description}</p></div><div className={`workspace-icon ${config.tone}`}><Icon size={30}/></div></div>

    {active === "Weather" && <div className="workspace-grid">
      <div className="panel weather-detail"><SectionHeader title={farmLocation} action="Refresh"/><div className="detail-weather"><div className="detail-temp"><Sun size={54}/><strong>{Math.round(weather?.current?.temperature ?? 28)}°C</strong><span>{weather?.current?.label ?? "Partly cloudy"} · {weather?.source ?? "Loading farm weather"}</span></div><div className="metric-cards"><div><Droplets size={18}/>Humidity <b>{weather?.current?.humidity ?? 72}%</b></div><div><CloudSun size={18}/>Rain chance <b>{weather?.current?.rainProbability ?? 20}%</b></div><div><Wind size={18}/>Wind <b>{weather?.current?.windSpeed ?? 12} km/h</b></div><div><ThermometerSun size={18}/>Rain now <b>{weather?.current?.rainfall ?? 0} mm</b></div></div></div></div>
      <div className="panel action-panel"><SectionHeader title="Today's recommendation"/><div className="recommendation"><ShieldCheck size={22}/><div><b>{(weather?.current?.rainProbability ?? 20) > 50 ? `Delay irrigation for ${cropName}` : `Water ${cropName} before 8 AM`}</b><p>Recommendation updates from the weather snapshot and the crop stored in your farm profile.</p></div></div><div className="mini-timeline"><span>Now</span><b>{Math.round(weather?.current?.temperature ?? 28)}°</b><span>Forecast</span><b>{Math.round(weather?.daily?.[1]?.max ?? 31)}°</b><span>Rain chance</span><b>{weather?.current?.rainProbability ?? 20}%</b></div></div>
      <div className="panel wide-panel"><SectionHeader title="5-day outlook" action="Calendar view"/><div className="outlook-row">{(weather?.daily ?? []).map((day: any, index: number)=><div className="outlook-day" key={day.date}><span>{day.probability > 50 ? "🌦️" : "☀️"}</span><b>{index === 0 ? "Today" : new Date(day.date).toLocaleDateString("en-IN", { weekday: "short" })}</b><strong>{Math.round(day.max)}° / {Math.round(day.min)}°</strong><small>{day.probability > 50 ? "Rain likely" : "Good for field work"}</small></div>)}</div></div>
    </div>}

    {active === "Mandi Prices" && <div className="workspace-grid">
      <div className="panel wide-panel"><SectionHeader title={`${farm?.district ?? "Meerut"} mandi · ${market?.live ? "Live today" : "Database snapshot"}`} action="Compare markets"/><div className="market-summary"><div><span>Best moving crop</span><b>Mustard <em>↗ +3%</em></b></div><div><span>Average basket value</span><b>₹ 2,766 <small>per quintal</small></b></div><div><span>Data source</span><b>{market?.live ? "Agmarknet" : "Project DB"}</b></div></div><div className="market-table"><div className="table-head"><span>Crop</span><span>Today's price</span><span>Market</span><span>Trend</span></div>{(market?.items ?? fallbackMarketRows).map((r: any)=><div className="market-row" key={r.commodity}><span className="crop"><i>{cropEmoji[r.commodity] ?? "🌱"}</i>{r.commodity}</span><b>₹ {Number(r.modalPrice).toLocaleString("en-IN")}</b><span>{r.market ?? `${farm?.district ?? "Meerut"} Mandi`}</span><em className={Number(r.change)===0?"flat":"up"}>↗ {r.change}%</em></div>)}</div><div className="data-source-note">{market?.source ?? "Market records are loading from the project database…"}</div></div>
      <div className="panel action-panel"><SectionHeader title="Sell smarter"/><div className="recommendation market"><TrendingUp size={22}/><div><b>Mustard is trending up</b><p>Consider selling in the next 2–3 days if you have storage available.</p><button className="text-action" onClick={()=>toast.success("Sell recommendation saved to your plan")}>Save recommendation →</button></div></div></div>
      <div className="panel wide-panel"><SectionHeader title="Price movement" action="Last 30 days"/><div className="fake-chart"><span>₹5,460</span><svg viewBox="0 0 700 100" preserveAspectRatio="none"><path d="M0 80 C80 78 110 55 170 68 S260 34 320 52 S410 78 470 41 S560 58 620 20 S670 35 700 10" fill="none" stroke="#2f9964" strokeWidth="4"/><path d="M0 80 C80 78 110 55 170 68 S260 34 320 52 S410 78 470 41 S560 58 620 20 S670 35 700 10 V100 H0Z" fill="#e6f4e9"/></svg><div><small>1 Aug</small><small>15 Aug</small><small>30 Aug</small></div></div></div>
    </div>}

    {active === "Disease Detection" && <div className="workspace-grid">
      <div className="panel upload-panel"><div className="dropzone"><div className="drop-icon"><Upload size={26}/></div><h3>Upload a crop or leaf photo</h3><p>Clear, well-lit images help us give a better diagnosis.</p><input id="crop-image-upload" type="file" accept="image/png,image/jpeg" hidden onChange={(event) => handleDiseaseUpload(event.target.files?.[0])}/><label className="upload-btn" htmlFor="crop-image-upload"><Upload size={15}/> {diseaseMutation.isPending ? "Analyzing…" : "Choose image"}</label><span>PNG, JPG up to 10 MB · Scan history is stored in your project database</span></div></div>
      <div className="panel action-panel"><SectionHeader title="Focused pilot crops"/><div className="pilot-list"><div><Leaf size={18}/><b>Wheat</b><span>Yellow rust · fungal spots</span></div><div><Sprout size={18}/><b>Rice</b><span>Blast · brown spot</span></div><div><ShoppingBasket size={18}/><b>Mustard</b><span>Aphids · leaf curl</span></div></div>{recentScans?.[0] && <div className="data-source-note">Last saved scan: {recentScans[0].diagnosis.slice(0, 120)}…</div>}</div>
      <div className="panel wide-panel"><SectionHeader title="How it works"/><div className="steps"><div><b>01</b><span>Upload a clear leaf image</span></div><div><b>02</b><span>AI checks visual symptoms</span></div><div><b>03</b><span>Diagnosis and image reference are saved</span></div></div></div>
    </div>}

    {active === "Decision Engine" && <div className="workspace-grid">
      <div className="panel wide-panel decision-panel"><SectionHeader title="Today's farm decision" action="Refresh analysis"/><div className="decision-card"><div className="decision-badge"><Sparkles size={18}/> {savedRecommendation.confidence}</div><h2>{savedRecommendation.title}</h2><p>{savedRecommendation.body}</p><div className="decision-factors">{factorList.map((factor: string) => <span key={factor}><ShieldCheck size={15}/> {factor}</span>)}</div><button className="upload-btn" onClick={()=>toast.success("Decision feedback saved")}>Mark as helpful</button></div></div>
      <div className="panel action-panel"><SectionHeader title="Context used"/><div className="context-list"><span><ShieldCheck size={16}/> Farm profile <b>{farm?.id ? "Complete" : "Loading"}</b></span><span><Leaf size={16}/> Soil test <b>{soil ? `Updated ${new Date(soil.testedAt).toLocaleDateString("en-IN")}` : "Not added"}</b></span><span><CloudSun size={16}/> Weather <b>{weather?.source?.includes("live") ? "Live" : "Database"}</b></span><span><TrendingUp size={16}/> Market <b>{market?.live ? "Live" : "Database"}</b></span></div></div>
      <div className="panel wide-panel"><SectionHeader title="Next 7 days"/><div className="decision-calendar">{["Today","Thu","Fri","Sat","Sun","Mon","Tue"].map((day,i)=><div key={day} className={i===0?"today":""}><b>{day}</b><span>{["Water check","Rain watch","Leaf scan","Nutrient check","Mandi review","Irrigation","Harvest plan"][i]}</span></div>)}</div></div>
    </div>}

    {active === "Alerts" && <div className="workspace-grid"><div className="panel wide-panel"><SectionHeader title="All active alerts" action="Mark all read"/><div>{(alerts ?? []).map((alert: any) => <div className="full-alert" key={alert.id}><i className={alert.severity === "medium" ? "yellow" : "red"}/><div><b>{alert.title}</b><p>{alert.message}</p></div><small>{new Date(alert.createdAt).toLocaleDateString("en-IN")}</small><button onClick={()=>toast.success("Alert marked as read")}>Dismiss</button></div>)}</div></div><div className="panel action-panel"><SectionHeader title="Alert preferences"/><div className="toggle-row"><span>Weather risk alerts</span><b>ON</b></div><div className="toggle-row"><span>Market movement alerts</span><b>ON</b></div><div className="toggle-row"><span>Crop health alerts</span><b>ON</b></div></div></div>}

    {active === "Farm Profile" && <div className="workspace-grid farm-profile-workspace"><div className="panel wide-panel"><div className="farm-profile-heading"><div><div className="eyebrow">FARM DETAILS</div><h2>Farm Profile</h2><p>These details power location-aware weather, crop advice, disease guidance and irrigation suggestions.</p></div><button className="upload-btn" onClick={saveFarmProfile} disabled={profileUpdateMutation.isPending}>{profileUpdateMutation.isPending ? "Saving…" : "Save profile"}</button></div><div className="farm-profile-sections"><div><h3>Farm details</h3><div className="farm-profile-grid"><label>Location<input value={farmProfileForm.location} onChange={(event) => updateFarmProfileField("location", event.target.value)} placeholder="Village, district, state" /></label><label>Farm size (acres)<input inputMode="decimal" value={farmProfileForm.farmSizeAcres} onChange={(event) => updateFarmProfileField("farmSizeAcres", event.target.value)} /></label><label>Irrigation source<select value={farmProfileForm.irrigationMethod} onChange={(event) => updateFarmProfileField("irrigationMethod", event.target.value)}><option>Tube well</option><option>Canal</option><option>Rainfed</option><option>Drip irrigation</option></select></label><label>Irrigation frequency<select value={farmProfileForm.irrigationFrequency} onChange={(event) => updateFarmProfileField("irrigationFrequency", event.target.value)}><option>Every 3 days</option><option>Every 7 days</option><option>Every 10 days</option><option>As needed</option></select></label><label>Soil type<input value={farmProfileForm.soilType} onChange={(event) => updateFarmProfileField("soilType", event.target.value)} placeholder="Loam, clay, sandy..." /></label><label className="checkbox-field"><span>Soil report available?</span><input type="checkbox" checked={farmProfileForm.soilReportAvailable === 1} onChange={(event) => updateFarmProfileField("soilReportAvailable", event.target.checked ? 1 : 0)} /></label></div></div><div><h3>Crop details</h3><div className="farm-profile-grid"><label>Crop name<input value={farmProfileForm.cropName} onChange={(event) => updateFarmProfileField("cropName", event.target.value)} /></label><label>Variety<input value={farmProfileForm.cropVariety} onChange={(event) => updateFarmProfileField("cropVariety", event.target.value)} /></label><label>Sowing date<input type="date" value={farmProfileForm.sowingDate} onChange={(event) => updateFarmProfileField("sowingDate", event.target.value)} /></label><label>Harvesting date<input type="date" value={farmProfileForm.harvestDate} onChange={(event) => updateFarmProfileField("harvestDate", event.target.value)} /></label><label>Treatment date<input type="date" value={farmProfileForm.treatmentDate} onChange={(event) => updateFarmProfileField("treatmentDate", event.target.value)} /></label><label>Treatment quantity<input value={farmProfileForm.treatmentQuantity} onChange={(event) => updateFarmProfileField("treatmentQuantity", event.target.value)} placeholder="e.g. 2 litres / acre" /></label></div></div></div></div><div className="panel action-panel"><SectionHeader title="Why we ask"/><div className="context-list"><span><CloudSun size={16}/> Weather personalization <b>Location</b></span><span><Leaf size={16}/> Crop health guidance <b>Crop</b></span><span><Droplets size={16}/> Irrigation planning <b>Soil</b></span><span><ShieldCheck size={16}/> Better decisions <b>All fields</b></span></div></div></div>}

    {active === "Settings" && <div className="workspace-grid"><div className="panel wide-panel"><SectionHeader title="Farmer profile" action={editingProfile ? undefined : "Edit profile"} onAction={() => setEditingProfile(true)} />{editingProfile ? <div className="profile-editor"><div className="profile-editor-intro"><div className="large-avatar">{(profileForm.farmerName || "S").charAt(0).toUpperCase()}</div><div><h3>Edit your farm context</h3><p>These details power weather, mandi and decision recommendations.</p></div></div><div className="profile-form-grid"><label>Farmer name<input value={profileForm.farmerName} onChange={(event) => updateProfileField("farmerName", event.target.value)} /></label><label>Farm size (acres)<input inputMode="decimal" value={profileForm.farmSizeAcres} onChange={(event) => updateProfileField("farmSizeAcres", event.target.value)} /></label><label>Location<input value={profileForm.location} onChange={(event) => updateProfileField("location", event.target.value)} /></label><label>District<input value={profileForm.district} onChange={(event) => updateProfileField("district", event.target.value)} /></label><label>State<input value={profileForm.state} onChange={(event) => updateProfileField("state", event.target.value)} /></label><label>Preferred language<select value={profileForm.language} onChange={(event) => updateProfileField("language", event.target.value)}><option>English · Hindi</option><option>Hindi</option><option>English</option><option>Punjabi</option></select></label><label>Irrigation method<select value={profileForm.irrigationMethod} onChange={(event) => updateProfileField("irrigationMethod", event.target.value)}><option>Tube well</option><option>Canal</option><option>Rainfed</option><option>Drip irrigation</option></select></label><label>Farming preference<select value={profileForm.farmingPreference} onChange={(event) => updateProfileField("farmingPreference", event.target.value)}><option>Conventional</option><option>Organic</option><option>Natural farming</option><option>Integrated</option></select></label></div><div className="profile-form-actions"><button className="cancel-btn" onClick={() => setEditingProfile(false)}>Cancel</button><button className="upload-btn" onClick={saveProfile} disabled={profileMutation.isPending}>{profileMutation.isPending ? "Saving…" : "Save profile"}</button></div></div> : <><div className="profile-card"><div className="large-avatar">{(farm?.farmerName ?? "Sneha").charAt(0)}</div><div><h3>{farm?.farmerName ?? "Sneha Sharma"}</h3><p><MapPin size={14}/> {farmLocation} · {farm?.farmSizeAcres ?? "4.5"} acres</p><span>Preferred language: {farm?.language ?? "English · Hindi"}</span></div></div><div className="settings-fields"><div><label>Primary crop</label><b>{cropName}</b></div><div><label>Crop stage</label><b>{cropStage}</b></div><div><label>Farming preference</label><b>{farm?.farmingPreference ?? "Conventional"}</b></div><div><label>Irrigation method</label><b>{farm?.irrigationMethod ?? "Tube well"}</b></div></div></>}</div><div className="panel action-panel"><SectionHeader title="Language & voice"/><div className="language-choice"><Languages size={19}/><div><b>{farm?.language ?? "English · Hindi"}</b><span>Saved in the farm profile database</span></div><ChevronRight size={16}/></div><div className="language-choice"><Mic size={19}/><div><b>Voice input</b><span>Ready for your next question</span></div><b className="status-on">ON</b></div><button className="logout-button" onClick={onLogout}>Log out of Kisaan-Kareer</button></div></div>}
  </div>;
}

function Home() {
  const { logout } = useAuth();
  const [active, setActive] = useState("Home");
  const [chat, setChat] = useState("");
  const [chatMessages, setChatMessages] = useState<Array<{ from: "user" | "ai"; text: string }>>([]);
  const farmQuery = trpc.farm.profile.useQuery();
  const cropQuery = trpc.farm.primaryCrop.useQuery();
  const soilQuery = trpc.farm.soil.useQuery();
  const recommendationQuery = trpc.decision.current.useQuery();
  const alertsQuery = trpc.alerts.list.useQuery();
  const chatQuery = trpc.chat.history.useQuery();
  const recentScansQuery = trpc.disease.recent.useQuery();
  const farm = farmQuery.data;
  const crop = cropQuery.data;
  const coordinates = useMemo(() => ({ latitude: Number(farm?.latitude ?? fallbackCoordinates.latitude), longitude: Number(farm?.longitude ?? fallbackCoordinates.longitude) }), [farm?.latitude, farm?.longitude]);
  const marketInput = useMemo(() => ({ district: farm?.district ?? "Meerut" }), [farm?.district]);
  const weatherQuery = trpc.weather.current.useQuery(coordinates, { enabled: Boolean(farm), staleTime: 300_000, refetchInterval: 300_000 });
  const marketQuery = trpc.market.list.useQuery(marketInput, { enabled: Boolean(farm), staleTime: 300_000, refetchInterval: 300_000 });
  const assistantMutation = trpc.assistant.ask.useMutation();
  const farmsQuery = trpc.farm.list.useQuery();
  const farmIdInput = useMemo(() => ({ farmId: farm?.id ?? 0 }), [farm?.id]);
  const cropsQuery = trpc.farm.crops.useQuery(farmIdInput, { enabled: Boolean(farm?.id) });
  const treatmentsQuery = trpc.farm.treatments.useQuery(farmIdInput, { enabled: Boolean(farm?.id) });
  const irrigationsQuery = trpc.farm.irrigations.useQuery(farmIdInput, { enabled: Boolean(farm?.id) });
  const soilSuggestionQuery = trpc.soil.suggest.useQuery(coordinates, { enabled: Boolean(farm), staleTime: 86_400_000 });
  const profileUpdateMutation = trpc.farm.update.useMutation({ onSuccess: async () => { await Promise.all([farmQuery.refetch(), cropQuery.refetch(), cropsQuery.refetch()]); toast.success("Farm profile saved"); } });
  const createFarmMutation = trpc.farm.create.useMutation({ onSuccess: async () => { await farmsQuery.refetch(); toast.success("New farm added"); } });
  const createCropMutation = trpc.farm.addCrop.useMutation({ onSuccess: async () => { await Promise.all([cropsQuery.refetch(), cropQuery.refetch()]); toast.success("New crop added"); } });
  const addTreatmentMutation = trpc.farm.addTreatment.useMutation({ onSuccess: async () => { await treatmentsQuery.refetch(); toast.success("Treatment date saved"); } });
  const addIrrigationMutation = trpc.farm.addIrrigation.useMutation({ onSuccess: async () => { await irrigationsQuery.refetch(); toast.success("Irrigation date saved"); } });
  const [farmProfileForm, setFarmProfileForm] = useState({ location: "", farmSizeAcres: "", irrigationMethod: "", irrigationFrequency: "", soilType: "", soilReportAvailable: 0, chemicalName: "", cropName: "", cropVariety: "", sowingDate: "", harvestDate: "", treatmentDate: "", treatmentQuantity: "" });
  useEffect(() => {
    if (!farm) return;
    setFarmProfileForm({ location: farm.location ?? "", farmSizeAcres: farm.farmSizeAcres ?? "", irrigationMethod: farm.irrigationMethod ?? "", irrigationFrequency: (farm as any).irrigationFrequency ?? "", soilType: (farm as any).soilType ?? "", soilReportAvailable: Number((farm as any).soilReportAvailable ?? 0), cropName: crop?.name ?? "", cropVariety: crop?.variety ?? "", sowingDate: crop?.sowingDate ?? "", harvestDate: (crop as any)?.harvestDate ?? "", treatmentDate: (crop as any)?.treatmentDate ?? "", treatmentQuantity: (crop as any)?.treatmentQuantity ?? "", chemicalName: (crop as any)?.chemicalName ?? "" });
  }, [farm, crop]);
  const updateFarmProfileField = (field: string, value: string | number) => setFarmProfileForm((current) => ({ ...current, [field]: value }));
  const saveFarmProfile = () => profileUpdateMutation.mutate(farmProfileForm);
  const addFarm = (input: any) => createFarmMutation.mutate(input);
  const addCrop = (input: any) => createCropMutation.mutate(input);
  const addTreatment = (input: any) => addTreatmentMutation.mutate(input);
  const addIrrigation = (input: any) => addIrrigationMutation.mutate(input);

  useEffect(() => {
    if (chatQuery.data?.length) setChatMessages(chatQuery.data.map((message: any) => ({ from: message.role === "assistant" ? "ai" : "user", text: message.content })));
  }, [chatQuery.data]);

  const navigate = (label: string) => setActive(label);
  const sendMessage = async () => {
    const value = chat.trim();
    if (!value) return;
    setChat("");
    setChatMessages((messages) => [...messages, { from: "user", text: value }]);
    try {
      const result = await assistantMutation.mutateAsync({ question: value, history: chatMessages.slice(-8).map((item) => ({ role: item.from === "ai" ? "assistant" as const : "user" as const, content: item.text })) });
      setChatMessages((messages) => [...messages, { from: "ai", text: result.answer }]);
    } catch {
      setChatMessages((messages) => [...messages, { from: "ai", text: "Check soil moisture first and water in the early morning. I’ll keep this recommendation practical while the AI service reconnects." }]);
    }
  };
  const displayName = farm?.farmerName ?? "Sneha";
  const alerts = alertsQuery.data ?? [];

  return <div className="app-shell">
    <aside className="sidebar"><div className="brand"><div className="brand-mark"><Sprout size={25} strokeWidth={2.4} /></div><div><div className="brand-name">Kisaan-Kareer</div><div className="brand-tag">Better Decisions. Healthier Crops.<br/>Prosperous Farmers.</div></div></div><nav>{navItems.map(({ label, icon: Icon }) => <button key={label} className={`nav-item ${active === label ? "active" : ""}`} onClick={() => navigate(label)}><Icon size={19} /><span>{label}</span></button>)}</nav><button className="nav-item settings" onClick={() => navigate("Settings")}><Settings size={19} /><span>Settings</span></button><div className="sidebar-note"><div className="note-copy">Empowering<br/>farmers with<br/><b>AI and real-time<br/>insights.</b></div><div className="field-doodle">⌁<span>♧</span>⌁</div></div></aside>
    <main className="main-area"><header className="topbar"><button className="mobile-menu"><Menu size={21}/></button><div className="searchbar"><Search size={18}/><input placeholder="Search for crops, diseases, or ask a question..." /></div><div className="profile-actions"><button className="icon-button" onClick={() => toast.info(alerts.length ? `${alerts.length} farm alerts in your database` : "You’re all caught up")}><Bell size={20}/><span className="notification-dot" /></button><button className="profile" onClick={() => navigate("Settings")} aria-label="Open profile settings"><div className="avatar">{displayName.charAt(0)}</div><div><b>{displayName.split(" ")[0]}</b><span>Farmer</span></div><ChevronDown size={16}/></button></div></header>
      <div className={`content-grid ${(active !== "Home" && active !== "Chat with AI") ? "workspace-layout" : ""}`}>
        {active !== "Home" && active !== "Chat with AI" && <Workspace active={active} onNavigate={navigate} onLogout={logout} farmProfileForm={farmProfileForm} updateFarmProfileField={updateFarmProfileField} saveFarmProfile={saveFarmProfile} profileUpdateMutation={profileUpdateMutation} farms={farmsQuery.data ?? []} crops={cropsQuery.data ?? []} treatments={treatmentsQuery.data ?? []} irrigations={irrigationsQuery.data ?? []} soilSuggestion={soilSuggestionQuery.data} onAddFarm={addFarm} onAddCrop={addCrop} onAddTreatment={addTreatment} onAddIrrigation={addIrrigation} weather={weatherQuery.data} market={marketQuery.data} farm={farm} crop={crop} soil={soilQuery.data} recommendation={recommendationQuery.data} alerts={alerts} recentScans={recentScansQuery.data} />}
        {active === "Home" && <section className="dashboard-content"><div className="hero-card" style={{ backgroundImage: `linear-gradient(90deg, rgba(244,250,236,.98) 0%, rgba(244,250,236,.88) 47%, rgba(244,250,236,.18) 100%), url(${heroImage})` }}><div><div className="eyebrow">YOUR FARM • {farm?.location ?? "MEERUT, UTTAR PRADESH"}</div><h1>Good Morning, {displayName}! <span>👩‍🌾</span></h1><p>Here’s what’s happening with your crops today.</p></div><div className="quote">“Sahi jaankari,<br/><b>behtar fasal.</b>”</div></div><div className="quick-actions">{quickActions.map(({ title, sub, target, icon: Icon, tone }) => <button className="quick-card" key={title} onClick={() => navigate(target)}><div className={`quick-icon ${tone}`}><Icon size={25}/></div><strong>{title}</strong><span>{sub}</span></button>)}</div>
          <div className="two-col"><div className="panel weather-panel"><SectionHeader title="Current Weather" /><div className="location"><MapPin size={15} fill="currentColor" /> {farm?.location ?? "Meerut, Uttar Pradesh"} · {weatherQuery.data?.source ?? "Loading…"}</div><div className="weather-main"><div className="weather-temp"><div className="sun-cloud"><Sun size={42}/><CloudSun size={32}/></div><div><strong>{Math.round(weatherQuery.data?.current?.temperature ?? 28)}°C</strong><span>{weatherQuery.data?.current?.label ?? "Partly Cloudy"}</span></div></div><div className="weather-metrics"><div><Droplets size={15}/>Humidity <b>{weatherQuery.data?.current?.humidity ?? 72}%</b></div><div><CloudSun size={15}/>Rainfall Prob. <b>{weatherQuery.data?.current?.rainProbability ?? 20}%</b></div><div><Wind size={15}/>Wind Speed <b>{weatherQuery.data?.current?.windSpeed ?? 12} km/h</b></div></div></div><div className="forecast">{(weatherQuery.data?.daily ?? []).slice(0,4).map((day: any, index: number) => <div key={day.date}><b>{day.probability > 50 ? "🌦️" : "☀️"}</b><span>{index === 0 ? "Today" : new Date(day.date).toLocaleDateString("en-IN", { weekday: "short" })}</span><small>{Math.round(day.max)}° / {Math.round(day.min)}°</small></div>)}</div></div><div className="panel mandi-panel"><SectionHeader title="Mandi Prices" action="View All →" onAction={() => navigate("Mandi Prices")} /><div className="table-head"><span>Crop</span><span>Price (₹/quintal)</span><span>Market</span></div>{(marketQuery.data?.items ?? fallbackMarketRows).slice(0,4).map((r: any) => <div className="price-row" key={r.commodity}><span className="crop"><i>{cropEmoji[r.commodity] ?? "🌱"}</i>{r.commodity}</span><b>₹ {Number(r.modalPrice).toLocaleString("en-IN")}</b><span>{r.market ?? "Meerut Mandi"}</span><em className={Number(r.change) === 0 ? "flat" : "up"}>↗ {r.change}%</em></div>)}</div></div>
          <div className="two-col bottom-row"><div className="panel alerts-panel"><SectionHeader title="Active Alerts" action="View All →" onAction={() => navigate("Alerts")} />{alerts.slice(0,3).map((alert: any) => <div className="alert-item" key={alert.id}><i className={alert.severity === "medium" ? "yellow" : "red"}/><div><b>{alert.title}</b><span>{alert.message}</span></div><small>{new Date(alert.createdAt).toLocaleDateString("en-IN")}</small></div>)}</div><div className="panel disease-panel"><SectionHeader title="Disease Detection" action="Try Now →" onAction={() => navigate("Disease Detection")} /><div className="disease-body"><div className="leaf-image"><Leaf size={44}/><span>{cropName(crop?.name)}</span></div><div><b>Upload a photo of your crop</b><p>Get instant diagnosis and treatment recommendations using AI.</p><button className="upload-btn" onClick={() => navigate("Disease Detection")}><Upload size={15}/> Upload Image</button></div></div></div></div></section>}
        {(active === "Home" || active === "Chat with AI") && <aside className="assistant-panel"><div className="assistant-heading"><div className="sparkle"><Sparkles size={21}/></div><div><h2>AI Farming Assistant</h2><p>Your 24/7 farming companion · chat saved to database</p></div></div><div className="chat-scroll">{chatMessages.map((message, index) => message.from === "user" ? <div className="chat-row user-row" key={index}><div className="user-bubble">{message.text}</div><div className="mini-user">{displayName.charAt(0)}</div></div> : <div className="chat-row ai-row" key={index}><div className="bot-mark"><Sprout size={16}/></div><div className="ai-bubble">{message.text}</div></div>)}</div><div className="chat-context"><Leaf size={13}/> Based on your saved farm profile, crop and live signals</div><div className="composer"><textarea value={chat} onChange={e => setChat(e.target.value)} onKeyDown={e => { if(e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }}} placeholder="Ask anything about farming..."/><div className="composer-actions"><button onClick={() => toast.info("Voice input is ready for the next demo step")}><Mic size={18}/></button><button><Paperclip size={18}/></button><button className="send-button" onClick={sendMessage} disabled={assistantMutation.isPending}><Send size={17}/></button></div></div></aside>}
      </div>
    </main>
  </div>;
}

function cropName(name?: string) { return (name ?? "Wheat").toUpperCase() + " LEAF"; }

export default Home;
