# Kisaan-Kareer: App Summary

**Prepared for:** Hackathon presentation and project documentation  
**Application type:** Full-stack farmer decision-support dashboard  
**Project name:** Kisaan-Kareer  
**Current checkpoint:** `c926e886`

## 1. Executive Summary

Kisaan-Kareer is a farmer-focused digital assistant that helps users make better day-to-day farming decisions. It combines live weather information, mandi price intelligence, crop-health support, personalized recommendations, alerts, and an AI farming assistant in one dashboard.

The product is designed around a simple principle: **clear information should lead to a practical farming action**. Instead of presenting disconnected data, Kisaan-Kareer translates weather, crop, soil, and market signals into understandable recommendations for irrigation, spraying, harvesting, crop monitoring, and selling decisions.

The current prototype is a functional full-stack web application. It includes a React interface, an Express and tRPC backend, a MySQL-compatible database layer through Drizzle ORM, server-side AI integrations, file storage support, and authentication-ready infrastructure.

## 2. Problem Statement

Small and medium-sized farmers often need to consult multiple sources for weather forecasts, crop disease identification, market prices, and cultivation advice. These sources may be difficult to understand, may not be localized, or may not provide a single clear next step.

Kisaan-Kareer addresses this problem by bringing essential farming signals into one localized workspace. The initial experience is configured for a farmer named Sneha Sharma in Meerut, Uttar Pradesh, with wheat as the primary crop. The architecture is designed so that this context can later be replaced by a signed-in farmer’s actual profile.

## 3. Core User Experience

The home dashboard provides a quick overview of current farm conditions. It includes a greeting and farm location, a live weather card, mandi prices, active alerts, crop disease detection, quick actions, and an AI assistant panel.

The persistent sidebar gives access to the following workspaces:

| Workspace | Purpose | Current functionality |
|---|---|---|
| Home | Daily farm overview | Displays weather, mandi prices, alerts, disease entry point, and assistant chat |
| Weather | Farming activity planning | Shows live current conditions and a five-day forecast for Meerut |
| Mandi Prices | Selling and market decisions | Displays crop prices, market context, trends, and data-source status |
| Disease Detection | Crop-health screening | Accepts a crop or leaf image and sends it for server-side AI analysis |
| Decision Engine | Personalized recommendations | Presents actionable decisions using crop, weather, soil, and market context |
| Chat with AI | Natural-language farming guidance | Sends questions to the server-side AI assistant |
| Alerts | Proactive risk monitoring | Shows weather, market, and crop-health alerts |
| Settings | Farmer profile context | Presents location, farm size, crop, language, irrigation, and farming preferences |

## 4. Major Features

### 4.1 Live Weather Intelligence

Weather data is retrieved from the Open-Meteo forecast API using the farm’s latitude and longitude. The dashboard displays temperature, humidity, rainfall probability, wind speed, weather condition, and a five-day outlook.

Weather data is refreshed through the client query layer with a five-minute refresh interval. The backend normalizes the provider response into a stable application format so that the user interface is not tightly coupled to the external provider’s response structure.

The weather workspace also generates a simple action-oriented interpretation. For example, high rainfall probability can result in a recommendation to delay irrigation, while lower rainfall probability can support an early-morning watering recommendation.

### 4.2 Mandi Price Intelligence

The market workspace is designed to consume daily commodity prices from the Indian government’s Agmarknet dataset through the data.gov.in API. The configured resource is the current daily price dataset for commodities across markets.

When a `DATA_GOV_API_KEY` is not configured, the app uses a clearly identified demonstration snapshot for wheat, rice, mustard, sugarcane, and potato. This fallback ensures that the interface remains usable during a hackathon demonstration without presenting demo values as live values.

The interface shows the crop, modal price, market, trend, market summary, and data-source status. When live access is enabled, the source indicator changes to identify the data.gov.in and Agmarknet feed.

### 4.3 AI Farming Assistant

The AI assistant accepts natural-language questions about irrigation, crop health, weather, market prices, and farm activities. Questions are sent to the server-side AI integration rather than exposing credentials in the browser.

The assistant receives relevant farm context, including location, farm size, farming preference, primary crop, and crop stage. The system prompt instructs the assistant to provide concise, practical guidance with a clear action, timing, and reason.

If the AI service is temporarily unavailable, the application returns a safe farming-rules fallback instead of failing silently. User and assistant messages are prepared for persistence in the `chatMessages` database table.

### 4.4 Crop Disease Detection

The disease-detection workspace accepts PNG and JPEG crop images. The image is converted into a server request, uploaded to managed storage, and then passed to the AI vision integration for analysis.

The response is designed to include the likely issue, confidence or uncertainty, severity guidance, and recommended next steps. The assistant is instructed not to claim certainty and to recommend confirmation by a local agronomist when appropriate.

The application stores the image reference rather than storing raw image bytes in the database. This keeps the database smaller and follows the recommended object-storage pattern.

### 4.5 Farmer Profile and Persistent Data

The database schema includes tables for users, farms, crops, soil tests, market prices, alerts, and chat messages. A farm profile stores the farmer’s name, location, district, state, coordinates, farm size, language, irrigation method, and farming preference.

The current UI uses a demo farm profile when a user is not signed in. The backend is authentication-ready and can associate persisted records with the signed-in user’s OAuth identifier.

### 4.6 Alerts and Decision Support

The alerts workspace groups weather, market, and crop-health signals. Alerts include a type, severity, title, message, creation time, and optional read time.

The decision-engine workspace communicates one recommended action at a time. The current experience includes irrigation timing, weather risk, crop stage, soil moisture, and market context as decision factors. This structure can later be expanded with a recommendation scoring model or a rules engine.

## 5. Technical Architecture

Kisaan-Kareer uses a React and TypeScript frontend with an Express and tRPC backend. tRPC provides typed procedures shared between the server and client, reducing the need to manually maintain REST endpoint contracts.

The application uses Drizzle ORM for database access. Database tables are defined in the `drizzle/schema.ts` file and are mapped to a MySQL-compatible database. The schema migration for the farmer-specific tables has been generated and applied.

The architecture separates external services from the user interface. Weather and market providers are called by the backend. AI requests and image-storage operations are also handled server-side. The frontend consumes typed procedures such as `weather.current`, `market.list`, `assistant.ask`, and `disease.analyze`.

| Layer | Technology | Responsibility |
|---|---|---|
| Frontend | React 19, TypeScript, Tailwind CSS, Lucide icons | Dashboard layout, navigation, forms, data presentation, responsive UI |
| Client data layer | tRPC React, TanStack Query | Typed API calls, caching, refresh intervals, mutation states |
| Backend | Express, tRPC 11 | API procedures, validation, external-service orchestration |
| Database | MySQL-compatible database, Drizzle ORM | User, farm, crop, soil, alert, market, and chat persistence |
| Authentication | Manus OAuth-ready infrastructure | Session handling and user association |
| AI | Manus built-in LLM integration | Farming chat and crop-image analysis |
| File storage | Managed object storage | Crop-image upload and retrieval |
| Weather provider | Open-Meteo | Current conditions and forecast data |
| Market provider | data.gov.in / Agmarknet adapter | Indian mandi price data |

## 6. Database Model

The main database entities are summarized below.

| Table | Important fields | Purpose |
|---|---|---|
| `users` | `openId`, `name`, `email`, `role` | Stores authenticated user identities |
| `farms` | `ownerOpenId`, location, coordinates, farm size, preferences | Stores farmer and farm context |
| `crops` | `farmId`, name, variety, stage, sowing date | Stores active crop information |
| `soilTests` | `farmId`, pH, nitrogen, phosphorus, potassium, organic carbon | Stores soil-health information |
| `marketPrices` | district, market, commodity, modal price, date, source | Stores normalized market records |
| `alerts` | owner, type, severity, title, message, read time | Stores farmer-specific notifications |
| `chatMessages` | owner, role, content, created time | Stores assistant conversation history |

## 7. API Procedures

The primary backend procedures are listed below.

| Procedure | Type | Function |
|---|---|---|
| `auth.me` | Query | Returns the current authenticated user when available |
| `auth.logout` | Mutation | Clears the session cookie |
| `farm.profile` | Query | Returns the current farmer profile or demo profile |
| `farm.primaryCrop` | Query | Returns the primary crop for the farmer’s farm |
| `farm.update` | Mutation | Updates persisted farm-profile fields |
| `weather.current` | Query | Retrieves and normalizes live weather data |
| `market.list` | Query | Retrieves live market data or a labeled fallback snapshot |
| `alerts.list` | Query | Returns farmer alerts or demo alerts |
| `alerts.markRead` | Mutation | Marks an alert as read |
| `assistant.ask` | Mutation | Sends a farm-contextual question to the AI assistant |
| `disease.analyze` | Mutation | Uploads an image and requests AI crop-health analysis |

## 8. Current Project Status

The application has passed the following validation checks:

| Check | Result |
|---|---|
| TypeScript validation | Passed with no errors |
| Automated tests | 5 tests passed across 2 test files |
| Production frontend build | Passed |
| Production backend bundle | Passed |
| Local weather procedure smoke test | Passed with live Open-Meteo response |
| Local farm-profile procedure smoke test | Passed |
| Local alerts procedure smoke test | Passed |
| Preview screenshot | Captured successfully |
| WebDev checkpoint | Saved as `c926e886` |

## 9. Known Limitations

The Mandi Prices workspace requires a valid `DATA_GOV_API_KEY` to retrieve live data from data.gov.in. Without the key, the application displays a labeled demonstration snapshot.

The current farmer profile is seeded with demo context for Sneha Sharma and Meerut. Authentication infrastructure is present, but a complete onboarding flow for entering a farmer’s location, crop, acreage, soil data, and language preference should be added before production use.

The disease-detection response is an AI-assisted screening result. It should not be treated as a definitive agronomic diagnosis. Production deployment should add image-size validation, stronger file-content validation, rate limiting, and a clear referral path to an agricultural expert.

The decision engine currently presents a structured recommendation experience. A production version should connect it to persisted soil tests, crop calendars, local agronomy rules, and a stronger recommendation evaluation layer.

## 10. Recommended Hackathon Demonstration Flow

Begin on the home dashboard and explain that the farmer sees one view of the farm instead of separate weather, market, and crop-health tools. Open the Weather workspace and point out that the conditions are retrieved from a live provider.

Next, open Mandi Prices and show the price table, trend indicators, and source label. Explain that the application supports a live Agmarknet adapter and uses a clearly labeled fallback when an API key is not available.

Then open Disease Detection and upload a leaf image. Explain that the image is stored securely and analyzed by the server-side AI integration. Finish by asking the AI assistant a practical question such as, “Should I irrigate my wheat tomorrow if rain is expected?”

The strongest closing message is that Kisaan-Kareer does not only display agricultural data. It turns that data into a practical next step for the farmer.

## 11. Future Roadmap

The next product milestone should add farmer onboarding with location search, farm-size entry, crop selection, crop-stage tracking, and soil-test upload. This would replace the current demonstration profile with personalized user data.

The following milestone should add multilingual support, voice input, localized crop calendars, stronger disease classification, and WhatsApp or SMS alerts. These capabilities would improve accessibility for farmers who prefer regional languages or low-bandwidth communication.

A later milestone should add historical analytics. The app could compare weather, market prices, crop actions, and outcomes over time to help farmers understand which decisions improve yield, water use, and selling outcomes.

## References

[1]: https://open-meteo.com/en/docs "Open-Meteo Weather Forecast API Documentation"

[2]: https://data.gov.in/resource/current-daily-price-various-commodities-various-markets-mandi "Current Daily Price of Various Commodities from Various Markets — data.gov.in"

[3]: https://agmarknet.gov.in/ "Agmarknet Agricultural Marketing Information Network"
